"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Link2, Video, Globe, Copy, Check, Loader2, Play, Info, CheckCircle2, ExternalLink } from "lucide-react"

const QUALITY_OPTIONS = [
  { value: "best", label: "Mejor calidad disponible", format: "bv*+ba/b" },
  { value: "4k", label: "4K (2160p)", format: "bv*[height<=2160]+ba/b[height<=2160]" },
  { value: "1080p", label: "1080p (Full HD)", format: "bv*[height<=1080]+ba/b[height<=1080]" },
  { value: "720p", label: "720p (HD)", format: "bv*[height<=720]+ba/b[height<=720]" },
  { value: "480p", label: "480p (SD)", format: "bv*[height<=480]+ba/b[height<=480]" },
  { value: "360p", label: "360p", format: "bv*[height<=360]+ba/b[height<=360]" },
]

const TOOLS_VERIFIED_KEY = "video-downloader-tools-verified"

interface VideoInfo {
  title: string
  thumbnail: string
  duration: string
  channel: string
  formats: Array<{ quality: string; format_id: string; ext: string; filesize?: number }>
}

function SetupScreen({ onConfirm }: { onConfirm: () => void }) {
  const [ytdlpChecked, setYtdlpChecked] = useState(false)
  const [ffmpegChecked, setFfmpegChecked] = useState(false)

  const canContinue = ytdlpChecked && ffmpegChecked

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-2xl">
        <header className="mb-8 text-center">
          <h1 className="mb-2 text-3xl font-bold text-foreground md:text-4xl">
            Video Downloader
          </h1>
          <p className="text-muted-foreground">
            Configuracion inicial - Solo una vez
          </p>
        </header>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Herramientas necesarias</CardTitle>
            <CardDescription>
              Para usar esta aplicacion necesitas tener instaladas las siguientes herramientas en tu computadora.
              Una vez confirmado, no te volveremos a preguntar.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div
                className={`flex items-start gap-4 rounded-lg border p-4 cursor-pointer transition-colors ${ytdlpChecked ? "border-green-500 bg-green-500/10" : "border-border hover:border-primary/50"
                  }`}
                onClick={() => setYtdlpChecked(!ytdlpChecked)}
              >
                <div className={`mt-0.5 flex h-5 w-5 items-center justify-center rounded border ${ytdlpChecked ? "border-green-500 bg-green-500" : "border-muted-foreground"
                  }`}>
                  {ytdlpChecked && <Check className="h-3 w-3 text-white" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground">yt-dlp</h3>
                    <a
                      href="https://github.com/yt-dlp/yt-dlp/releases"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Herramienta de linea de comandos para descargar videos de YouTube y otros sitios.
                  </p>
                  <div className="mt-2 rounded bg-muted p-2">
                    <code className="text-xs text-foreground">
                      # Windows (winget)<br />
                      winget install yt-dlp<br /><br />
                      # macOS (brew)<br />
                      brew install yt-dlp<br /><br />
                      # Linux<br />
                      sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp<br />
                      sudo chmod a+rx /usr/local/bin/yt-dlp
                    </code>
                  </div>
                </div>
              </div>

              <div
                className={`flex items-start gap-4 rounded-lg border p-4 cursor-pointer transition-colors ${ffmpegChecked ? "border-green-500 bg-green-500/10" : "border-border hover:border-primary/50"
                  }`}
                onClick={() => setFfmpegChecked(!ffmpegChecked)}
              >
                <div className={`mt-0.5 flex h-5 w-5 items-center justify-center rounded border ${ffmpegChecked ? "border-green-500 bg-green-500" : "border-muted-foreground"
                  }`}>
                  {ffmpegChecked && <Check className="h-3 w-3 text-white" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground">FFmpeg</h3>
                    <a
                      href="https://www.gyan.dev/ffmpeg/builds/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Necesario para combinar video y audio en un solo archivo MP4.
                  </p>
                  <div className="mt-2 rounded bg-muted p-2">
                    <code className="text-xs text-foreground">
                      # Windows (winget)<br />
                      winget install ffmpeg<br /><br />
                      # macOS (brew)<br />
                      brew install ffmpeg<br /><br />
                      # Linux (apt)<br />
                      sudo apt install ffmpeg
                    </code>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-lg bg-muted/50 p-4">
              <h4 className="font-medium text-foreground mb-2">Verificar instalacion</h4>
              <p className="text-sm text-muted-foreground mb-2">
                Abre una terminal y ejecuta estos comandos para verificar:
              </p>
              <div className="rounded bg-muted p-2">
                <code className="text-xs text-foreground">
                  yt-dlp --version<br />
                  ffmpeg -version
                </code>
              </div>
            </div>

            <Button
              onClick={onConfirm}
              disabled={!canContinue}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
              size="lg"
            >
              {canContinue ? (
                <>
                  <CheckCircle2 className="mr-2 h-5 w-5" />
                  Confirmar y continuar
                </>
              ) : (
                "Marca ambas casillas para continuar"
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export function VideoDownloader() {
  const [toolsVerified, setToolsVerified] = useState<boolean | null>(null)
  const [url, setUrl] = useState("")
  const [quality, setQuality] = useState("best")
  const [loading, setLoading] = useState(false)
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null)
  const [command, setCommand] = useState("")
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [activeTab, setActiveTab] = useState("youtube")

  useEffect(() => {
    const verified = localStorage.getItem(TOOLS_VERIFIED_KEY)
    setToolsVerified(verified === "true")
  }, [])

  const handleToolsConfirm = () => {
    localStorage.setItem(TOOLS_VERIFIED_KEY, "true")
    setToolsVerified(true)
  }

  const handleResetVerification = () => {
    localStorage.removeItem(TOOLS_VERIFIED_KEY)
    setToolsVerified(false)
  }

  if (toolsVerified === null) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!toolsVerified) {
    return <SetupScreen onConfirm={handleToolsConfirm} />
  }

  const fetchVideoInfo = async () => {
    if (!url.trim()) {
      setError("Por favor ingresa una URL")
      return
    }

    setLoading(true)
    setError("")
    setVideoInfo(null)
    setCommand("")

    try {
      const response = await fetch("/api/video-info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim() }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Error al obtener informacion del video")
      }

      setVideoInfo(data)
      generateCommand(data.title)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error desconocido")
    } finally {
      setLoading(false)
    }
  }

  const generateCommand = (title?: string) => {
    const videoTitle = title || videoInfo?.title || "video"
    const safeTitle = videoTitle.replace(/[<>:"/\\|?*]/g, "_").substring(0, 100)
    const selectedQuality = QUALITY_OPTIONS.find(q => q.value === quality)
    const format = selectedQuality?.format || "bv*+ba/b"

    const cmd = `yt-dlp -f "${format}" --merge-output-format mp4 -o "${safeTitle}.%(ext)s" "${url.trim()}"`
    setCommand(cmd)
  }

  const copyCommand = async () => {
    try {
      await navigator.clipboard.writeText(command)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      setError("No se pudo copiar al portapapeles")
    }
  }

  const handleQualityChange = (value: string) => {
    setQuality(value)
    if (videoInfo) {
      const videoTitle = videoInfo.title
      const safeTitle = videoTitle.replace(/[<>:"/\\|?*]/g, "_").substring(0, 100)
      const selectedQuality = QUALITY_OPTIONS.find(q => q.value === value)
      const format = selectedQuality?.format || "bv*+ba/b"
      const cmd = `yt-dlp -f "${format}" --merge-output-format mp4 -o "${safeTitle}.%(ext)s" "${url.trim()}"`
      setCommand(cmd)
    }
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-4xl">
        <header className="mb-8 text-center">
          <h1 className="mb-2 text-3xl font-bold text-foreground md:text-4xl">
            Video Downloader
          </h1>
          <p className="text-muted-foreground">
            Descarga videos de YouTube y otras plataformas en la calidad que prefieras
          </p>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6 grid w-full grid-cols-2">
            <TabsTrigger value="youtube" className="flex items-center gap-2">
              <Video className="h-4 w-4" />
              YouTube
            </TabsTrigger>
            <TabsTrigger value="other" className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              Otros sitios
            </TabsTrigger>
          </TabsList>

          <TabsContent value="youtube">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Video className="h-5 w-5 text-primary" />
                  Descargar de YouTube
                </CardTitle>
                <CardDescription>
                  Pega la URL del video y selecciona la calidad deseada
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col gap-3 sm:flex-row">
                  <div className="relative flex-1">
                    <Link2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      type="url"
                      placeholder="https://www.youtube.com/watch?v=..."
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      className="bg-input pl-10"
                    />
                  </div>
                  <Select value={quality} onValueChange={handleQualityChange}>
                    <SelectTrigger className="w-full bg-input sm:w-48">
                      <SelectValue placeholder="Calidad" />
                    </SelectTrigger>
                    <SelectContent>
                      {QUALITY_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={fetchVideoInfo}
                  disabled={loading || !url.trim()}
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Obteniendo info...
                    </>
                  ) : (
                    <>
                      <Download className="mr-2 h-4 w-4" />
                      Generar comando de descarga
                    </>
                  )}
                </Button>

                {error && (
                  <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
                    {error}
                  </div>
                )}

                {videoInfo && (
                  <div className="space-y-4 rounded-lg bg-secondary/50 p-4">
                    <div className="flex gap-4">
                      {videoInfo.thumbnail && (
                        <img
                          src={videoInfo.thumbnail}
                          alt={videoInfo.title}
                          className="h-24 w-40 rounded-lg object-cover"
                          crossOrigin="anonymous"
                        />
                      )}
                      <div className="flex-1 space-y-1">
                        <h3 className="font-semibold text-foreground line-clamp-2">
                          {videoInfo.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {videoInfo.channel}
                        </p>
                        {videoInfo.duration && (
                          <p className="text-sm text-muted-foreground">
                            Duracion: {videoInfo.duration}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {command && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium text-foreground">
                        Comando para descargar:
                      </label>
                      <button
                        onClick={copyCommand}
                        className="flex items-center gap-1.5 rounded-md px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                        title="Copy command"
                      >
                        {copied ? (
                          <>
                            <Check className="h-4 w-4" style={{ color: '#808080' }} />
                            <span style={{ color: '#808080' }}>Copiado</span>
                          </>
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                    <div>
                      <pre className="overflow-x-auto rounded-lg bg-muted p-4 text-sm text-foreground">
                        <code>{command}</code>
                      </pre>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Copia este comando y ejecutalo en tu terminal.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="other">
            <OtherSitesDownloader />
          </TabsContent>
        </Tabs>

        <footer className="mt-8 space-y-4">
          <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              Herramientas verificadas
            </span>
            <button
              onClick={handleResetVerification}
              className="text-primary hover:underline"
            >
              Reconfigurar
            </button>
          </div>
          <p className="text-center text-sm text-muted-foreground">
            Esta herramienta genera comandos para yt-dlp. Los videos se descargan localmente en tu computadora.
          </p>
        </footer>
      </div>
    </div>
  )
}

function OtherSitesDownloader() {
  const [url, setUrl] = useState("")
  const [quality, setQuality] = useState("1080p")
  const [loading, setLoading] = useState(false)
  const [command, setCommand] = useState("")
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const generateCommand = () => {
    if (!url.trim()) {
      setError("Por favor ingresa una URL")
      return
    }

    setError("")
    setLoading(true)

    setTimeout(() => {
      const qualityFormat = quality === "best"
        ? "bv*+ba/b"
        : `bv*[height<=${quality.replace("p", "")}]+ba/b[height<=${quality.replace("p", "")}]`

      const cmd = `yt-dlp -f "${qualityFormat}" --merge-output-format mp4 -o "%(title)s.%(ext)s" "${url.trim()}"`
      setCommand(cmd)
      setLoading(false)
    }, 300)
  }

  const copyCommand = async () => {
    try {
      await navigator.clipboard.writeText(command)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      setError("No se pudo copiar al portapapeles")
    }
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5 text-primary" />
          Descargar de otros sitios
        </CardTitle>
        <CardDescription>
          Genera comandos de descarga para Twitter, TikTok, Instagram y mas
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Link2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="url"
              placeholder="https://twitter.com/... o https://tiktok.com/..."
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="bg-input pl-10"
            />
          </div>
          <Select value={quality} onValueChange={setQuality}>
            <SelectTrigger className="w-full bg-input sm:w-48">
              <SelectValue placeholder="Calidad" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="best">Mejor calidad</SelectItem>
              <SelectItem value="4k">4K (2160p)</SelectItem>
              <SelectItem value="1080p">1080p (Full HD)</SelectItem>
              <SelectItem value="720p">720p (HD)</SelectItem>
              <SelectItem value="480p">480p (SD)</SelectItem>
              <SelectItem value="360p">360p</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button
          onClick={generateCommand}
          disabled={loading || !url.trim()}
          className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generando...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Generar comando
            </>
          )}
        </Button>

        {error && (
          <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
            {error}
          </div>
        )}

        {command && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-foreground">
                Comando de descarga:
              </label>
              <button
                onClick={copyCommand}
                className="flex items-center gap-1.5 rounded-md px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                title="Copy command"
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4" style={{ color: '#808080' }} />
                    <span style={{ color: '#808080' }}>Copiado</span>
                  </>
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </button>
            </div>
            <div>
              <pre className="overflow-x-auto rounded-lg bg-muted p-4 text-sm text-foreground">
                <code>{command}</code>
              </pre>
            </div>
            <p className="text-xs text-muted-foreground">
              yt-dlp soporta mas de 1000 sitios web.
            </p>
          </div>
        )}

        <div className="rounded-lg bg-muted/50 p-4">
          <h4 className="mb-2 font-medium text-foreground">Sitios soportados:</h4>
          <p className="text-sm text-muted-foreground">
            Twitter/X, Facebook, Instagram, TikTok, Vimeo, Dailymotion, Twitch, Reddit,
            SoundCloud, Bandcamp, y mas de 1000 sitios adicionales.
          </p>
          <a
            href="https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 inline-flex items-center gap-1 text-sm text-primary hover:underline"
          >
            Ver lista completa
            <ExternalLink className="h-3 w-3" />
          </a>
        </div>
      </CardContent>
    </Card>
  )
}
