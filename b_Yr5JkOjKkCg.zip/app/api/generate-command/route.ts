import { NextRequest, NextResponse } from "next/server"

interface CommandRequest {
  url: string
  quality: string
  title?: string
  outputFormat?: string
}

const QUALITY_FORMATS: Record<string, string> = {
  best: "bv*+ba/b",
  "4k": "bv*[height<=2160]+ba/b[height<=2160]",
  "2160p": "bv*[height<=2160]+ba/b[height<=2160]",
  "1080p": "bv*[height<=1080]+ba/b[height<=1080]",
  "720p": "bv*[height<=720]+ba/b[height<=720]",
  "480p": "bv*[height<=480]+ba/b[height<=480]",
  "360p": "bv*[height<=360]+ba/b[height<=360]",
  "audio": "ba/b",
}

function sanitizeFilename(title: string): string {
  // Remove characters that are invalid in filenames
  return title
    .replace(/[<>:"/\\|?*]/g, "_")
    .replace(/\s+/g, " ")
    .trim()
    .substring(0, 200) // Limit filename length
}

export async function POST(request: NextRequest) {
  try {
    const body: CommandRequest = await request.json()
    const { url, quality = "best", title, outputFormat = "mp4" } = body

    if (!url || typeof url !== "string") {
      return NextResponse.json(
        { error: "URL es requerida" },
        { status: 400 }
      )
    }

    // Validate URL format
    try {
      new URL(url)
    } catch {
      return NextResponse.json(
        { error: "URL no valida" },
        { status: 400 }
      )
    }

    const formatString = QUALITY_FORMATS[quality.toLowerCase()] || QUALITY_FORMATS.best
    
    // Build the command
    let outputTemplate: string
    if (title) {
      const safeTitle = sanitizeFilename(title)
      outputTemplate = `"${safeTitle}.%(ext)s"`
    } else {
      // Use video title from the source
      outputTemplate = '"%(title)s.%(ext)s"'
    }

    // Basic command
    let command = `yt-dlp -f "${formatString}"`
    
    // Add merge format for video downloads
    if (quality !== "audio") {
      command += ` --merge-output-format ${outputFormat}`
    }

    // Add output template
    command += ` -o ${outputTemplate}`

    // Add the URL
    command += ` "${url}"`

    // Generate additional useful commands
    const commands = {
      basic: command,
      withMetadata: `${command} --embed-metadata --embed-thumbnail`,
      withSubtitles: `${command} --write-subs --sub-langs es,en`,
      audioOnly: `yt-dlp -f "ba/b" -x --audio-format mp3 -o ${outputTemplate} "${url}"`,
      listFormats: `yt-dlp -F "${url}"`,
      downloadPlaylist: command.replace("-o", "--yes-playlist -o"),
    }

    return NextResponse.json({
      command: commands.basic,
      commands: commands,
      quality: quality,
      format: formatString,
      outputTemplate: outputTemplate,
    })

  } catch (error) {
    console.error("Error generating command:", error)
    return NextResponse.json(
      { error: "Error al generar el comando" },
      { status: 500 }
    )
  }
}
