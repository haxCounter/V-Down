import { NextRequest, NextResponse } from "next/server"

interface StreamInfo {
  url: string
  quality: string
  type: string
}

// List of supported sites by yt-dlp (partial list for display)
const SUPPORTED_SITES = [
  "youtube.com",
  "youtu.be",
  "twitter.com",
  "x.com",
  "facebook.com",
  "instagram.com",
  "tiktok.com",
  "vimeo.com",
  "dailymotion.com",
  "twitch.tv",
  "reddit.com",
  "soundcloud.com",
  "bandcamp.com",
  "bilibili.com",
  "nicovideo.jp",
  "pornhub.com",
  "xvideos.com",
  "xhamster.com",
  "redtube.com",
  "spankbang.com",
  "xnxx.com",
]

function isSupportedSite(url: string): boolean {
  try {
    const urlObj = new URL(url)
    const hostname = urlObj.hostname.toLowerCase().replace("www.", "")
    return SUPPORTED_SITES.some(site => hostname.includes(site.replace("www.", "")))
  } catch {
    return false
  }
}

function detectVideoType(url: string): string {
  const urlLower = url.toLowerCase()
  if (urlLower.includes(".m3u8")) return "HLS"
  if (urlLower.includes(".mpd")) return "DASH"
  if (urlLower.includes(".mp4")) return "MP4"
  if (urlLower.includes(".webm")) return "WebM"
  if (urlLower.includes(".flv")) return "FLV"
  return "Video"
}

export async function POST(request: NextRequest) {
  try {
    const { url } = await request.json()

    if (!url || typeof url !== "string") {
      return NextResponse.json(
        { error: "URL es requerida" },
        { status: 400 }
      )
    }

    // Validate URL format
    let parsedUrl: URL
    try {
      parsedUrl = new URL(url)
    } catch {
      return NextResponse.json(
        { error: "URL no valida" },
        { status: 400 }
      )
    }

    const isSupported = isSupportedSite(url)
    const videoType = detectVideoType(url)

    // For HLS/DASH streams, try to fetch and parse the manifest
    if (url.includes(".m3u8")) {
      try {
        const response = await fetch(url, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          },
        })

        if (response.ok) {
          const content = await response.text()
          const streams: StreamInfo[] = []

          // Parse M3U8 for quality options
          const lines = content.split("\n")
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim()
            if (line.startsWith("#EXT-X-STREAM-INF:")) {
              const resMatch = line.match(/RESOLUTION=(\d+)x(\d+)/)
              const bandwidthMatch = line.match(/BANDWIDTH=(\d+)/)
              
              if (resMatch && i + 1 < lines.length) {
                const streamUrl = lines[i + 1].trim()
                if (streamUrl && !streamUrl.startsWith("#")) {
                  const height = parseInt(resMatch[2])
                  const bandwidth = bandwidthMatch ? parseInt(bandwidthMatch[1]) : 0
                  
                  let quality = `${height}p`
                  if (height >= 2160) quality = "4K"
                  else if (height >= 1080) quality = "1080p (Full HD)"
                  else if (height >= 720) quality = "720p (HD)"
                  else if (height >= 480) quality = "480p"
                  else if (height >= 360) quality = "360p"

                  // Resolve relative URLs
                  let fullStreamUrl = streamUrl
                  if (!streamUrl.startsWith("http")) {
                    const baseUrl = url.substring(0, url.lastIndexOf("/") + 1)
                    fullStreamUrl = baseUrl + streamUrl
                  }

                  streams.push({
                    url: fullStreamUrl,
                    quality: quality,
                    type: "HLS",
                  })
                }
              }
            }
          }

          if (streams.length > 0) {
            // Sort by quality (highest first)
            streams.sort((a, b) => {
              const qualityOrder: Record<string, number> = {
                "4K": 5,
                "1080p (Full HD)": 4,
                "720p (HD)": 3,
                "480p": 2,
                "360p": 1,
              }
              return (qualityOrder[b.quality] || 0) - (qualityOrder[a.quality] || 0)
            })

            return NextResponse.json({
              streams: streams,
              supported: true,
              type: "HLS",
            })
          }
        }
      } catch (error) {
        console.error("Error parsing M3U8:", error)
      }
    }

    // For direct video files
    if (url.match(/\.(mp4|webm|mkv|avi|mov|flv)(\?|$)/i)) {
      return NextResponse.json({
        streams: [
          {
            url: url,
            quality: "Original",
            type: videoType,
          },
        ],
        supported: true,
        type: videoType,
      })
    }

    // For supported sites, suggest using yt-dlp
    return NextResponse.json({
      streams: [],
      supported: isSupported,
      message: isSupported 
        ? "Este sitio es soportado por yt-dlp. Usa el comando generado para descargar."
        : "Sitio no reconocido. Intenta con el comando yt-dlp, puede que funcione.",
      type: "webpage",
    })

  } catch (error) {
    console.error("Error analyzing stream:", error)
    return NextResponse.json(
      { error: "Error al analizar la URL" },
      { status: 500 }
    )
  }
}
