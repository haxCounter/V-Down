import { NextRequest, NextResponse } from "next/server"

interface YouTubeOEmbed {
  title: string
  author_name: string
  author_url: string
  thumbnail_url: string
  html: string
}

function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=)([^&\n?#]+)/,
    /(?:youtu\.be\/)([^&\n?#]+)/,
    /(?:youtube\.com\/embed\/)([^&\n?#]+)/,
    /(?:youtube\.com\/shorts\/)([^&\n?#]+)/,
    /(?:youtube\.com\/v\/)([^&\n?#]+)/,
  ]

  for (const pattern of patterns) {
    const match = url.match(pattern)
    if (match) return match[1]
  }
  return null
}

function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = seconds % 60

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }
  return `${minutes}:${secs.toString().padStart(2, "0")}`
}

export async function POST(request: NextRequest) {
  try {
    const { url } = await request.json()

    if (!url || typeof url !== "string") {
      return NextResponse.json(
        { error: "URL es requerida" },
        { status: 400 }
      )
    }

    const videoId = extractVideoId(url)

    if (!videoId) {
      return NextResponse.json(
        { error: "URL de YouTube no valida" },
        { status: 400 }
      )
    }

    // Use YouTube oEmbed API to get video info (no API key required)
    const oembedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`
    
    const oembedResponse = await fetch(oembedUrl, {
      headers: {
        "Accept": "application/json",
      },
    })

    if (!oembedResponse.ok) {
      return NextResponse.json(
        { error: "No se pudo obtener informacion del video. Verifica que la URL sea correcta y el video sea publico." },
        { status: 404 }
      )
    }

    const oembedData: YouTubeOEmbed = await oembedResponse.json()

    // Get high-quality thumbnail
    const thumbnail = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
    const fallbackThumbnail = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`

    // Check if maxres thumbnail exists
    let finalThumbnail = thumbnail
    try {
      const thumbResponse = await fetch(thumbnail, { method: "HEAD" })
      if (!thumbResponse.ok) {
        finalThumbnail = fallbackThumbnail
      }
    } catch {
      finalThumbnail = fallbackThumbnail
    }

    return NextResponse.json({
      title: oembedData.title,
      channel: oembedData.author_name,
      thumbnail: finalThumbnail,
      duration: "Duracion disponible al descargar",
      videoId: videoId,
      formats: [
        { quality: "4K (2160p)", format_id: "2160", ext: "mp4" },
        { quality: "1080p (Full HD)", format_id: "1080", ext: "mp4" },
        { quality: "720p (HD)", format_id: "720", ext: "mp4" },
        { quality: "480p (SD)", format_id: "480", ext: "mp4" },
        { quality: "360p", format_id: "360", ext: "mp4" },
      ],
    })
  } catch (error) {
    console.error("Error fetching video info:", error)
    return NextResponse.json(
      { error: "Error al procesar la solicitud" },
      { status: 500 }
    )
  }
}
